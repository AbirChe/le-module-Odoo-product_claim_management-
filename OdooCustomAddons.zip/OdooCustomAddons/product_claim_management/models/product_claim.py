import logging
from odoo import models, fields, api
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)  


class ProductClaim(models.Model):
    _name = 'product.claim'
    _description = 'Product Claim'
    _order = 'claim_date desc'

    user_id = fields.Many2one('res.users', string='Responsible', default=lambda self: self.env.user, required=True)

    name = fields.Char(
        'Reference',
        required=True,
        default=lambda self: self.env['ir.sequence'].next_by_code('product.claim') or '/'
    )
    customer_id = fields.Many2one('res.partner', string='Customer', required=True)
    order_id = fields.Many2one('sale.order', string='Order')
    product_id = fields.Many2one('product.product', string='Product')
    claim_date = fields.Datetime(string='Claim Date', default=fields.Datetime.now)
    description = fields.Text('Description')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('closed', 'Closed')
    ], string='State', default='draft')
    cause = fields.Selection([
        ('quality_issue', 'Quality Issue'),
        ('shipping_damage', 'Shipping Damage'),
        ('other', 'Other')
    ], string='Cause')
    resolution = fields.Text('Resolution')
    action = fields.Text('Corrective Actions')
    resolution_date = fields.Datetime(string='Resolution Date')
    processing_time = fields.Float(string='Processing Time')

    @api.model
    def create(self, vals):
        if not vals.get('name'):
            vals['name'] = self.env['ir.sequence'].next_by_code('product.claim') or '/'
        return super(ProductClaim, self).create(vals)

    def action_submit(self):
        for claim in self:
            if not claim.user_id:
                raise ValidationError("Please assign a responsible user before submitting the claim.")
            claim.state = 'in_progress'
        return True

    def action_resolve(self):
        for claim in self:
            if not claim.resolution:
                raise ValidationError('You must specify the resolution closing the claim.')           
            claim.state = 'resolved'
            claim.resolution_date = fields.Datetime.now()
        return True

    def action_close(self):
        for claim in self:
            if not claim.cause or not claim.action:
                raise ValidationError('You must specify the cause and corrective actions before closing the claim.')
            claim.state = 'closed'
        return True


class Product(models.Model):
    _inherit = 'product.product'

    claim_ids = fields.One2many(
        'product.claim', 'product_id', string='Product Claims'
    )
    claims_in_progress_count = fields.Integer(
        string='Claims In Progress',
        compute='_compute_claims_in_progress_count'
    )
    average_resolution_time = fields.Float(
        string='Average Resolution Time (days)',
        compute='_compute_average_resolution_time',
        help='Average time to resolve claims for this product, in days'
    )

    @api.depends('claim_ids.state')
    def _compute_claims_in_progress_count(self):
        for product in self:
            product.claims_in_progress_count = len(product.claim_ids.filtered(lambda c: c.state == 'in_progress'))

    @api.depends('claim_ids.resolution_date', 'claim_ids.claim_date')
    def _compute_average_resolution_time(self):
        for product in self:
            resolved_claims = product.claim_ids.filtered(lambda c: c.state == 'resolved' and c.resolution_date and c.claim_date)
            if resolved_claims:
                total_days = sum((claim.resolution_date - claim.claim_date).days for claim in resolved_claims)
                product.average_resolution_time = total_days / len(resolved_claims)
            else:
                product.average_resolution_time = 0


class ClaimReportWizard(models.TransientModel):
    _name = 'claim.report.wizard'
    _description = 'Claim Report Wizard'

    start_date = fields.Date(string='Start Date', required=True)
    end_date = fields.Date(string='End Date', required=True)

    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        for record in self:
            if record.end_date < record.start_date:
                raise ValidationError('The end date cannot be earlier than the start date.')

    def generate_report(self):
        _logger.info("Start date from the form: %s", self.start_date)
        _logger.info("End date from the form: %s", self.end_date)

        # Fetch claims based on the selected date range from the product.claim model
        claims = self.env['product.claim'].search([
            ('claim_date', '>=', self.start_date),
            ('claim_date', '<=', self.end_date)
        ])

        total_claims = len(claims)
        claim_by_cause = {}
        corrective_actions = {}
        total_processing_time = 0

        for claim in claims:
            # Aggregate claim counts by cause
            cause = claim.cause or 'Unknown Cause'  
            claim_by_cause[cause] = claim_by_cause.get(cause, 0) + 1
        
            # Aggregate corrective actions
            action = claim.action or 'Unknown Action'  
            corrective_actions[action] = corrective_actions.get(action, 0) + 1
        
            # Calculate total processing time
            if claim.processing_time:
                total_processing_time += claim.processing_time

        # Calculate average processing time
        average_processing_time = total_processing_time / total_claims if total_claims > 0 else 0

        # Prepare the data to be passed to the report
        data = {
            'start_date': str(self.start_date) if self.start_date else "N/A",
            'end_date': str(self.end_date) if self.end_date else "N/A",
            'total_claims': total_claims,
            'claim_by_cause': claim_by_cause,
            'corrective_actions': corrective_actions,
            'average_processing_time': round(average_processing_time, 2),  
        }

        # Logging to check the dynamic data
        _logger.info("Dynamic data passed to report: %s", data)

        # Call the report with the dynamically fetched data
        return self.env.ref('product_claim_management.action_report_product_claim').report_action(self, data={'data': data})
