{
    'name': 'Product Claim Management',
    'version': '1.0',
    'category': 'Sales',
    'summary': 'Manage product claims effectively',
    'author': 'abir chennoufi',
    'depends': ['base', 'sale', 'product'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'data/email_template.xml',
        'reports/product_claim_report_templates.xml',  
        'reports/product_claim_report.xml',            
        'views/product_claim_views.xml',               
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}





